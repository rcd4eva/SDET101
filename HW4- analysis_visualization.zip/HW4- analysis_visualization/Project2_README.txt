03/22/2025
By: Ricardo DaSilveira
For ECET 101-102 class.

Prof Craig Iaboni.

This script analyse dayli step counts of a 30 day period and prints some statistical data along with a graph.
Step numbers are internally generated, bu you can add your on by changing the "steps" list with your own values.
Size of the "steps" list can be more any size you like, 1 week, 60 days, one year, as long as each value corresponds 
to "one" day and the values are integers.
wit will highligh steps taken above a certain value. This value can be modified in the variable "threshold".

Dependencies:
Matplotlib
Python >= 3.9

