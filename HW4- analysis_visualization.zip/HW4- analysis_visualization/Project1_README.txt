03/22/2025
By: Ricardo DaSilveira
For ECET 101-102 class.

Prof Craig Iaboni.

# this program calcualte the Minimun, maximum, mean and median score of a list of grade scores.
#It prints the grades distribution on a historygram along side an line plot in the grades ascending order.
# a bried analyisis of the scores is also displayed along side the plotted graphs.

you can change the "scores" list to analyise your own data.

Dependencies:
Matplotlib
Python >= 3.9