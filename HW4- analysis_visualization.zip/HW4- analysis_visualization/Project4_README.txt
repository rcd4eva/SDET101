03/22/2025
By: Ricardo DaSilveira
For ECET 101-102 class.

Prof Craig Iaboni.

This script plots sales figures. IT loads the data from a csv file. 
File can be of any size as longs as it contains a properly formatted csv file with two coloumns, Month and Sales, including the column names.

If you are usign windows you migght newed to remove the "./" from the file name 

Dependencies:
Pandas
Matplotlib
Python >= 3.9
A csv file named monthly_sales.csv containg sales data in one columns, and the month in the other.


