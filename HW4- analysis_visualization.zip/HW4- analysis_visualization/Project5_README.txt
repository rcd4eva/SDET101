03/22/2025
By: Ricardo DaSilveira
For ECET 101-102 class.

Prof Craig Iaboni.

This script collect the past 1000 days of closing stock price for two selectable stocks.
It prints a line graph and two histograms along with some numbers for easy analysis.

Dependencies:
Pandas
Matplotlib
Python >= 3.9
A python file containg your API key.

To use this script you must have an API with https://www.alphavantage.co/
Once you have it, crate a file named api_key.py
Add to your api_key.py file the variable name "API_KEY" and assign your API key number as a string
Ex: API_KEY = "xxxxxxxx"

Assing "ticker1" and "ticker2" to the stock ticker of your interest, as a string
Ex: ticker1 = "AAPL" , ticker2 = "GOOG"
you can look up up to 2 stock tickers at once

Enjoy