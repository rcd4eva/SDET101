#============== PART 1 =============#
# a. Calculate and print the number of days with temperatures above 24°C.
# b. Identify and print the highest and lowest temperatures of the month.
print("SDET101-102 HW2, rcd4 - 212-05-998")
print("Question 1")
temperatures = [18, 22, 19, 25, 17, 21, 23, 20, 26, 24, 19, 22, 27, 21, 23, 18, 24, 25, 19, 20, 22, 26, 23, 21, 19, 24, 22, 20, 18, 23]
maxTemp = 24
peakTemp = 0
lowestTemp = 100
i=0

for t in temperatures:
    if t > maxTemp:
        i +=1
    if t > peakTemp:
        peakTemp = t
    if t < lowestTemp:
        lowestTemp = t
print(f"Number of hot days (above {maxTemp}\N{DEGREE SIGN}C): {i}")
print(f"Highet Temperature: {peakTemp}\N{DEGREE SIGN}C")
print(f"Lowest Temperature: {lowestTemp}\N{DEGREE SIGN}C\n")

# Question 2
# a. Calculates and prints the average score.
# b. Determines the number of students who passed and failed. (Assume a passing score is 70 or above.)
# c. Prints a message for each student indicating "Pass" or "Fail".

print("\nQuestion 2")
scores = [88, 76, 90, 85, 92, 67, 73, 81, 95, 78]
print("Average score:" + str(sum(scores)/len(scores)))
#b)
passGrade = 70
passStudents = len([g for g in scores if g >= passGrade])
failStudents = len(scores) - passStudents

print(f"number of students who passed:{passStudents}" )
print(f"number of students who failed:{failStudents}" )
i=0
for s in scores:
    i+=1
    if s >= passGrade:
        result ="Pass"    
    else:
        result="Fail"
    print(f"Student {i:02}: {result}")

# Question 3
# a. Identify items that need restocking (quantity less than 20).
# b. Calculate the total value of the current inventory.
# c. Increase the price of items with quantity less than 15 by 10%.
print("\nQuestion 3")
inventory = [
    {'item': 'Apple', 'quantity': 50, 'price': 0.5},
    {'item': 'Banana', 'quantity': 20, 'price': 0.3},
    {'item': 'Orange', 'quantity': 30, 'price': 0.7},
    {'item': 'Grapes', 'quantity': 15, 'price': 1.5},
    {'item': 'Mango', 'quantity': 10, 'price': 2.0},
]

r = [item['item'] for item in inventory if item['quantity'] < 20]
# for item in r :
#     print(item['item'])
print("Items to restock: " + ', ' .join(r))
#partb
total = sum(item['quantity'] * item['price'] for item in inventory)
print(f"Total inventory value: ${total}")
print("Updated Inventory Prices:")        
t = [item['item'] for item in inventory if item['quantity'] < 15]
print (t)


